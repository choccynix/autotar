# Notice

Copyright 2018-2024 Gavin D. Howard and contributors.

## Contributors

The contributors to `bc` (besides Gavin) are listed below in alphabetical order.

* Laurent Bercot (skarnet)
* Stefan Eßer (stesser)
* Michael Forney (michaelforney)
* John Regan (jprjr)
* rofl0r
* Zach van Rijn (me@zv.io)
